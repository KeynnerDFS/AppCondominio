﻿using Condominio.RegrasCondominio;
using static System.Runtime.InteropServices.JavaScript.JSType;
List<Casa> casas = new List<Casa>();

void CadastrarTurma()
{
    var contador = 0;
    int opcao = 1;
    while (opcao != 0)
    {
        Console.Clear();
        Console.WriteLine("########################## Cadastrar Casa ##########################");
        Console.WriteLine();
        Console.Write("Número da Casa....:");
        var numero = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine();

        Console.WriteLine("Tipos de casas: Básica o valor de R300 mil (1) , Padrão o valor de R500 mil (2), Alto Padrão o valor de R700 mil (3)");
        Console.WriteLine();
        Console.Write("Escolha uma opção acima:");
        var tipo = Convert.ToInt16(Console.ReadLine());

        Console.Write("Descrição do seu veiculo numero 1...:");
        var descricaoVeiculo1 = Console.ReadLine();
        Console.Write("Descrição do seu veiculo numero 2...:");
        var descricaoVeiculo2 = Console.ReadLine();

        Casa Novacasa = new Casa( numero,  tipo,  descricaoVeiculo1,  descricaoVeiculo2);
        // depois da sala criada, colocar a sala na lista
        casas.Add(Novacasa);
        contador++;

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("!!!Casa criada!!!\n");

        Console.ForegroundColor = ConsoleColor.White;
        Console.Write("Deseja continuar adicionando casa (S/N).....:");
        var resposta = Console.ReadLine().ToUpper();

        if (resposta == "N") opcao = 0;



    }//fim do While
}


var opc = 1;
while (opc != 0)
{
    Console.Clear();
    Console.WriteLine("########################## Condominio ##########################");
    Console.WriteLine();
    Console.WriteLine("1 - Cadastrar uma nova casa");
    Console.WriteLine("2 - Cadastrar moradores em uma casa ");
    Console.WriteLine("3 - Consultar moradores de uma casa");
    Console.WriteLine("4 - Consultar morador pelo nome");
    Console.WriteLine("5 - Filtrar moradores por nome");
    Console.WriteLine("6 - Filtrar moradores por salário");
    Console.WriteLine("7 - Filtrar moradores por tipo de casa");
    Console.WriteLine("8 - Mostrar o percentual de moradores por tipo de casa");
    Console.WriteLine("9 - Listar todos os moradores titulares");
    Console.WriteLine("0 - Encerrar Programa");
    Console.WriteLine();
    Console.WriteLine("Criadores: Einstein Guimarães e Keynner Davi");
    Console.WriteLine("Turma/Curso: 2ºA Técnico em Informática");

    Console.Write("Escolha uma opção....:");
    opc = Convert.ToInt32(Console.ReadLine());

    switch (opc)
    {

        case 1:
            {
                break;
            }
        case 2:
            {
                
                break;
            }
        case 3:
            {
                
                break;
            }
        case 4:
            {
                
                break;
            }
        case 5:
            {
                
                break;
            }
        case 6:
            {
                
                break;
            }
        case 7:
            {
                
                break;
            }
        case 8:
            {
               
                break;
            }
        case 9:
            {
               
                break;
            }
        case 0:
            {
               
                break;
            }
    }//fim do switch
}//fim do While