﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Condominio.RegrasCondominio
{
    public class Pessoa
    {
        public string Nome { get; set; }
        public string Genero{ get; set; }
        public string Cpf { get; set; }
        public double Renda { get; set; }
        public bool Titulo { get; set; }
    }
}
