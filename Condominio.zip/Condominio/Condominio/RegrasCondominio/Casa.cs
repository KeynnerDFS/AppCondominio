﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Condominio.RegrasCondominio
{
    public class Casa
    {
        public int Numero { get; set; }
        public int Tipo { get; set; }
        public string DescricaoVeiculo1 { get; set; }
        public string DescricaoVeiculo2 { get; set; }
        public double ValorCasa { get; set; }
        
        public double ValorDoCondominio { get; set; }

        public List<Pessoa> Moradores { get; set; }

        public Casa(int numero, int tipo, string descricaoVeiculo1, string descricaoVeiculo2)
        {
            this.Numero = numero;
            this.Tipo = tipo;
            this.DescricaoVeiculo1 = descricaoVeiculo1;
            this.DescricaoVeiculo1 = descricaoVeiculo2;
            Moradores = new List<Pessoa>();
        }

        public void ValorDaCasa()
        {
            if (Tipo == 1)
            {
                  ValorCasa = 300.000;
            }
            if (Tipo == 2)
            {
                ValorCasa = 500.000;
            }
            if (Tipo == 3) 
            {
                ValorCasa = 700.000;
            }
            else
            {
                Console.WriteLine("Tipo de Casa não encontrado");
            }
        }//fim
        public void ValorCondominio()
        {
            var numeroMoradores = Moradores.Count();
            ValorDoCondominio = (numeroMoradores * ValorCasa) * (0.1/100);
        }//fim

    }
}
